<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
* TextCaptcha
*
* A CAPTCHA is a test to tell humans and robots apart. 
* textCAPTCHA.com provides plaintext captchas based on simple logic questions.
*
* This class will talk to textCAPTCHA's API returning a question string and an array of possible answers.
* Grab an API key from http://textcaptcha.com/register
*
* @package Textcaptcha
* @copyright 2010, Gareth Poole
* @author Gareth Poole <http://www.garethpoole.co.uk>
* @license GPLv3
* @version 1.0.0
*/

class Textcaptcha
{
	private $_question;
	private $_answers = array();
	static private $url = 'http://textcaptcha.com/api/6fbsgavbx340sg0co0cggsog4';
	#static private $url = 'http://textcaptcha.com/api/' . 'YOUR KEY';
	private $_xml;
	
	
	/**
	 * Constructor
	 * Loads the XML from the API, pulls out the question and possible answers.
	 *
	 * @access	public
	 */
	public function __construct()
	{
		if(!$this->_answers)
		{
			try
			{
    			$this->_xml = @new SimpleXMLElement(self::$url,null,true);
			} 
			catch (Exception $e) 
			{
    			// if there is a problem, use static fallback..
    			$fallback = '<captcha>'.
    			  '<question>Is ice hot or cold?</question>'.
    			  '<answer>'.md5('cold').'</answer></captcha>';
    			$this->_xml = new SimpleXMLElement($fallback);
			}
		
			$this->_question = (string) $this->_xml->question;
		
			$ans = array();
			foreach (@$this->_xml->answer as $hash) {
	   		 	$this->_answers[] = (string)$hash;
			}
		}	
	}
	
	
	/**
	 * question() method
	 * Get the question string.
	 *
	 * @access public
	 */
	public function question()
	{
		if($this->_question)
			return $this->_question;	
	}
	
	
	/**
	 * answers() method
	 * Get the possible answers array.
	 *
	 * @access public
	 */
	public function answers()
	{
		if($this->_answers)
			return $this->_answers;	
	}
	
	
	/**
	 * validate()
	 * Pass a user generated answer and an array of MD5'd possible answers. 
	 * If MD5(user answer) is in the array, answer is correct
	 *
	 * @access public
	 */
	public function validate($ans, $possible_answers)
	{
		$answer = md5(trim($ans));
		if(!empty($possible_answers))
		if(in_array($answer, $possible_answers))
		{
			return true;
		}
	}
	
}